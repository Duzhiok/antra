package com.antra.evaluation.reporting_system.pojo.exception;

public class PDFGenerationException extends RuntimeException {
}

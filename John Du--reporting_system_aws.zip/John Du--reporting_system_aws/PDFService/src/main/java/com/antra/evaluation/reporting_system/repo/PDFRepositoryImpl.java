package com.antra.evaluation.reporting_system.repo;

import ch.qos.logback.classic.util.LogbackMDCAdapter;
import com.antra.evaluation.reporting_system.pojo.report.PDFFile;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class PDFRepositoryImpl implements ExcelRepository {

    Map<String, PDFFile> excelData = new ConcurrentHashMap();
    private LogbackMDCAdapter PDFData;


    public Optional<PDFFile> getFileById(String id) {
        return (Optional<PDFFile>) Optional.ofNullable(PDFData.get(id));
    }


    public PDFFile saveFile(PDFFile file) {
        return PDFData.put(file.getFileId(), file);
    }


    public PDFFile deleteFile(String id) {
        return PDFData.remove(id);
    }


    public List<PDFFile> getFiles() {
        return new ArrayList(PDFData.values());
    }
}


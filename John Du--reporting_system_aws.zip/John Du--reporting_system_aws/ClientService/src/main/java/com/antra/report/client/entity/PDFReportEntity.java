package com.antra.report.client.entity;

import javax.persistence.Entity;

@Entity(name="pdf_report")
public class PDFReportEntity extends BaseReportEntity{

}

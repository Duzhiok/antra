package com.antra.report.client.pojo;

public enum FileType {
    PDF, EXCEL
}

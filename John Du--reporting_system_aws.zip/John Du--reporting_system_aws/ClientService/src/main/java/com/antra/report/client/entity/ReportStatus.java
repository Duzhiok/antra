package com.antra.report.client.entity;

public enum ReportStatus {
    PENDING, COMPLETED, FAILED
}

package com.antra.report.client.entity;

import javax.persistence.Entity;

@Entity(name="excel_report")
public class ExcelReportEntity extends BaseReportEntity{

}

package com.antra.report.client;

import com.antra.report.client.pojo.reponse.ErrorResponse;
import com.antra.report.client.service.SNSService;
import org.junit.jupiter.api.TestTemplate;
import org.springframework.http.HttpStatus;
import com.antra.report.client.service.ReportService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

public class TestRes {

    @Autowired
    SNSService snsService;

    @Autowired
    ReportService reportService;

    @Test
    public void testStatus(){
        HttpStatus status = HttpStatus.valueOf(100);
        ErrorResponse r = new ErrorResponse(status, "saasfasfa");
    }


}
